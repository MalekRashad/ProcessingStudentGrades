﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace try13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declaring variables
            int iChoice;//users input menu choice
            int iIndex;//loop center
            int iNumofstudentGrades;//number of student grades to enter
            string sFileName;// the file ill be able to write to and read from
            int[] igrades = new int[6];//the grades for the modules
            double dCombinedGrade;//double to calculate the average
            double dAvgGrade;// average grade
            string sStudentNumber;//student number
            string sStudentName;//student name
            string[] sModules = new string[6];//modules and their names
            sModules[0] = "Math";
            sModules[1] = "English";
            sModules[2] = "Biology";
            sModules[3] = "Chemistry";
            sModules[4] = "History";
            sModules[5] = "Programming";


            //menu
            Console.WriteLine("1. enter grades for student");
            Console.WriteLine("2. view student grades");
            Console.WriteLine("3. exit program");
            Console.WriteLine();
            Console.Write("please select your choice: ");//users menu choice input
            iChoice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            // validating menu choice
            while (iChoice < 1 || iChoice > 3)
            {
                Console.Write("Error, choice must be between 1-3, please re-enter your choice : ");
                iChoice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
            }
            while (iChoice != 3)
            {
                Console.WriteLine();
                Console.Write("please enter the 9 digit student number: ");
                sStudentNumber = Console.ReadLine();// user inputting student number
                while (sStudentNumber.Length!= 9)// validating student number
                {
                    Console.Write("please enter a valid 9 digit student number: ");
                    sStudentNumber = Console.ReadLine();
                }
                sFileName = sStudentNumber;// naming file after student number in order to view indivisual student grades 

                if (iChoice == 1)
                {
                    using (StreamWriter sw = new StreamWriter(sFileName + ".txt"))// writing into text file
                    {
                        Console.Write("please enter student " + sStudentNumber + "'s name: ");
                        sStudentName = Console.ReadLine();
                        for (int i = 0; i < 6; i++)// loop to enter in student grades
                        {
                            Console.Write("please enter " + sStudentName + "'s " + sModules[i] + " grade: ");
                            igrades[i] = Convert.ToInt32(Console.ReadLine());
                            while (igrades[i] > 100 || igrades[i] < 0) // validating grade
                            {
                                Console.Write("please enter a valid grade between 1-100: ");
                                igrades[i] = Convert.ToInt32(Console.ReadLine());

                            }
                            Console.WriteLine();
                        }
                        dCombinedGrade = igrades[0] + igrades[1] + igrades[2] + igrades[3] + igrades[4] + igrades[5];// adding together the grade so i can later on divide them by the number of modules
                        dAvgGrade = CalculateAvg(dCombinedGrade);//calling back the calculating method
                        sw.WriteLine(sStudentNumber);//writing the system number into the text file
                        sw.WriteLine(sStudentName);// writing the student name into the text file
                        sw.WriteLine(dAvgGrade);//wiriting the student's average grade into the text file
                        sw.WriteLine(igrades[0]);// writing grades into text file
                        sw.WriteLine(igrades[1]);
                        sw.WriteLine(igrades[2]);
                        sw.WriteLine(igrades[3]);
                        sw.WriteLine(igrades[4]);
                        sw.WriteLine(igrades[5]);
                        sw.WriteLine(sModules[0]);// writing modules into text file
                        sw.WriteLine(sModules[1]);
                        sw.WriteLine(sModules[2]);
                        sw.WriteLine(sModules[3]);
                        sw.WriteLine(sModules[4]);
                        sw.WriteLine(sModules[5]);

                        
                            
                        
                        Console.WriteLine();
                    }
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("     view student grade     ");
                    Console.WriteLine();
                    using (StreamReader sr = new StreamReader(sFileName + ".txt"))// reading from text file
                    {
                        while (sr.Peek() != -1)// statement in order for the program not to crash
                        {
                            sStudentNumber = sr.ReadLine();// reading student number in to text file
                            sStudentName = sr.ReadLine();// reading student name into text file
                            dAvgGrade = Convert.ToDouble(sr.ReadLine()); // reading student average grade into text file
                            igrades[0]= Convert.ToInt32(sr.ReadLine());// reading grades into the text file 
                            igrades[1] = Convert.ToInt32(sr.ReadLine());
                            igrades[2] = Convert.ToInt32(sr.ReadLine());
                            igrades[3] = Convert.ToInt32(sr.ReadLine());
                            igrades[4] = Convert.ToInt32(sr.ReadLine());
                            igrades[5] = Convert.ToInt32(sr.ReadLine());
                            sModules[0] = sr.ReadLine();// reading modules into text file
                            sModules[1] = sr.ReadLine();
                            sModules[2] = sr.ReadLine();
                            sModules[3] = sr.ReadLine();
                            sModules[4] = sr.ReadLine();
                            sModules[5] = sr.ReadLine();


                            for (int i = 0; i < 6; i++)// loop to view student grades from text file
                            {
                                Console.WriteLine(sStudentName + " has scored " + igrades[i] + " out of 100 in " + sModules[i]);
                                Console.WriteLine();
                            }

                                if (dAvgGrade >= 40) // if statement to view student average and that they passed
                            {
                                Console.WriteLine();
                                Console.WriteLine(sStudentName + " has passed the year with an average of " + dAvgGrade);
                                Console.WriteLine();
                            }
                            else // else statement to view student average and that they failded
                            {
                                Console.WriteLine();
                                Console.WriteLine(sStudentName + " has failed the year with an average of " + dAvgGrade);
                                Console.WriteLine();
                            }
                        }
                        Console.WriteLine() ;

                    }
                }
                // menu again
                Console.WriteLine("1. enter grades for student");
                Console.WriteLine("2. view student grades");
                Console.WriteLine("3. exit program");
                Console.WriteLine();
                Console.Write("please select your choice: ");//users menu choice input
                iChoice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
                // validating menu choice
                while (iChoice < 1 || iChoice > 3)
                {
                    Console.Write("Error, choice must be between 1-3, please re-enter your choice : ");
                    iChoice = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();
                }
            }
            Console.WriteLine("press any key to close program");
            Console.ReadKey();
        }
        static double CalculateAvg(double pdCombinedGrade)//a function to calculte the student average
        {
            double dAvg; // variable
            dAvg = pdCombinedGrade / 6; // calculating student average
            return dAvg; // returning variable
        }
    }
}
